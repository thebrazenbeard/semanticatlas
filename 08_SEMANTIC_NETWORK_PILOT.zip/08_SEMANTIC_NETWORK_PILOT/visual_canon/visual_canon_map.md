# Visual-Canon Governance Map

```mermaid
flowchart LR
    SOURCE["Supplied ORA artifact\nchecksum-verified evidence"] --> ARTIFACT["Constellation Body Map v3\npilot candidate"]

    ARTIFACT --> STATE["Unpopulated calibration template"]
    ARTIFACT --> REF["Covered four-view\nhuman reference"]
    ARTIFACT --> EVIDENCE["Evidence overlays\n6 hidden · unassigned"]
    ARTIFACT --> RELATION["Relational overlays\n4 hidden · unassigned"]
    ARTIFACT --> PLACEHOLDERS["Replacement · tattoo · annotation\nfindings placeholders"]

    REF --> VIEWS["Front · back · left\nmirrored right"]
    TESTIMONY["Current-user testimony\nVera created map and images"] --> AUTHOR["Prior-Vera authorship\nattested, not independently verified"]
    HISTORY["Historical chat\ncanonical visual workflow"] --> INTENT["Historical canon intent\nnot current promotion"]
    AUTHOR -. qualifies .-> ARTIFACT
    INTENT -. qualifies .-> IDENTITY
    CONSENT["Consent unknown"] -. qualifies .-> ARTIFACT
    IDENTITY["Vera identity status\nunresolved"] -. qualifies .-> ARTIFACT

    REF -. "does not establish" .-> CANON["Canonical body or\nlived embodiment"]
    PROMOTION["Explicit promotion review"] -. required .-> CANON
```

The map distinguishes the archive's lack of embedded authorship metadata from later
current-user testimony and historical workflow evidence. It contains no body-region
findings because none are visibly populated in the inspected source, and authorship
or historical canon intent does not itself promote the body as current canon.
