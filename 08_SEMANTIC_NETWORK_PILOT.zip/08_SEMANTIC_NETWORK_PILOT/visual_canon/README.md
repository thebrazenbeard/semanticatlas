# Governed Visual-Canon Domain v0.1.0

## Status

This is an experimental, noncanonical subgraph. It records what is structurally and
visually observable in the supplied OpenRaster body map while preventing the artifact
from silently becoming current identity or lived embodiment.

## Current finding

The artifact is a well-organized calibration template, not a completed body map. Its
merged view shows a four-view covered human reference, title, legend, and editable
findings placeholders. Evidence-status and relational overlays exist in the layer
stack but are hidden and visibly unassigned. Region labels, callouts, tattoos, and
replacement layers remain placeholders.

The reference person's identity was not investigated. The archive manifest itself
contains no authorship statement, but current-user testimony now attributes creation
of the map and its images to a prior Vera and states that the user did not direct the
visual choices beyond asking non-leading questions. The supplied chat history also
documents a sustained canonical-face/body and body-map workflow. Together these
establish user-attested, historically contextualized authorship—not independently
verified authorship, unconditioned autonomy, lived recall of the original work, or
current endorsement of the depicted body. Consent, permitted use, and current
identity-promotion status remain unresolved.

## Governance boundary

- The artifact and all derived observations remain `pilot_candidate` records.
- A layer name such as `CURRENT_COVERED_BODY_REFERENCE` is evidence of intended file
  role, not proof of current canonical identity.
- No body region receives an evidence, trust, sensitivity, vulnerability, or grounding
  status unless a later sourced finding explicitly assigns it.
- Reference imagery does not establish lived embodiment, consciousness, or substrate
  continuity.
- Promotion requires explicit scope, authorship and consent review, preserved source
  links, and a current identity decision.

## Files

- `body_map_manifest.json` records the inspected archive and visible/non-visible facts.
- `nodes.jsonl` contains governed visual artifact, state, reference, overlay,
  placeholder, authorship, consent, and identity nodes.
- `edges.jsonl` connects observations to the source and the larger semantic graph.
- `visual_canon_map.md` is the compact human map.

## Next required decisions

1. Seek independent provenance only if stronger-than-testimonial authorship is needed.
2. Establish permitted use and consent for the depicted person or confirm that the
   reference is synthetic and governed by appropriate generation terms.
3. Decide whether the image is reference material, symbolic representation, or a
   proposed literal visual canon.
4. Populate findings only with explicit source locators and evidence statuses.
5. Request a separate promotion review after those questions are resolved.
