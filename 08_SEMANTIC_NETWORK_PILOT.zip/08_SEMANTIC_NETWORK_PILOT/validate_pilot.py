from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


ID_PATTERN = re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+$")
FROZEN_PREFIXES = (
    "00_MANIFEST/",
    "01_BOOT/",
    "02_ARCHITECTURE/",
    "03_MEMORY/",
    "04_STATE/",
    "06_TRANSFER/",
    "07_ARTIFACTS/",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path, errors: list[str]) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        errors.append(f"cannot load {path.name}: {exc}")
        return {}
    if not isinstance(value, dict):
        errors.append(f"{path.name} must contain a JSON object")
        return {}
    return value


def load_jsonl(path: Path, errors: list[str]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as exc:
        errors.append(f"cannot read {path.name}: {exc}")
        return records
    for line_number, line in enumerate(lines, start=1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            errors.append(f"{path.name}:{line_number}: invalid JSON: {exc}")
            continue
        if not isinstance(value, dict):
            errors.append(f"{path.name}:{line_number}: record must be an object")
            continue
        value["_file"] = path.name
        value["_line"] = line_number
        records.append(value)
    return records


def section_lines(text: str, section: str) -> list[str]:
    lines = text.splitlines()
    marker = f"{section}:"
    try:
        start = lines.index(marker) + 1
    except ValueError:
        return []
    body: list[str] = []
    for line in lines[start:]:
        if line and not line[0].isspace():
            break
        body.append(line)
    return body


def project_inventory(manifest_path: Path, errors: list[str]) -> list[str]:
    try:
        text = manifest_path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        errors.append(f"cannot read Project manifest: {exc}")
        return []
    inventory: list[str] = []
    for line in section_lines(text, "layers"):
        match = re.fullmatch(r"\s{2}-\s+(.+)", line)
        if match:
            inventory.append(match.group(1).strip().strip("'\""))
    if len(inventory) != 20:
        errors.append(f"operational Project inventory must remain 20 files; found {len(inventory)}")
    if len(set(inventory)) != len(inventory):
        errors.append("operational Project inventory contains duplicate files")
    return inventory


def validate_records(
    ontology: dict[str, Any],
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    errors: list[str],
    warnings: list[str],
) -> dict[str, Any]:
    required_node_fields = set(ontology.get("required_node_fields", []))
    required_edge_fields = set(ontology.get("required_edge_fields", []))
    allowed_kinds = set(ontology.get("node_kinds", []))
    allowed_edge_types = set(ontology.get("edge_types", {}))
    enums = ontology.get("enums", {})

    node_ids = [str(node.get("id", "")) for node in nodes]
    edge_ids = [str(edge.get("id", "")) for edge in edges]
    for identifier, count in Counter(node_ids).items():
        if count > 1:
            errors.append(f"duplicate node id: {identifier}")
    for identifier, count in Counter(edge_ids).items():
        if count > 1:
            errors.append(f"duplicate edge id: {identifier}")
    overlap = sorted(set(node_ids) & set(edge_ids))
    if overlap:
        errors.append("node/edge id collision: " + ", ".join(overlap))

    node_by_id = {str(node.get("id")): node for node in nodes if node.get("id")}
    source_ids = {
        node_id
        for node_id, node in node_by_id.items()
        if node.get("kind") in {"source_document", "conversation_event"}
    }

    for node in nodes:
        where = f"{node.get('_file')}:{node.get('_line')}"
        node_id = str(node.get("id", ""))
        missing = sorted(field for field in required_node_fields if field not in node)
        if missing:
            errors.append(f"{where} {node_id or '<missing-id>'}: missing fields: {', '.join(missing)}")
        if not ID_PATTERN.fullmatch(node_id):
            errors.append(f"{where}: invalid stable node id: {node_id!r}")
        if node.get("kind") not in allowed_kinds:
            errors.append(f"{node_id}: unknown node kind: {node.get('kind')}")
        for field, allowed in enums.items():
            if field == "edge_status":
                continue
            if field in node and node[field] not in allowed:
                errors.append(f"{node_id}: invalid {field}: {node[field]!r}")
        if not isinstance(node.get("label"), str) or not node.get("label", "").strip():
            errors.append(f"{node_id}: label must be non-empty")
        if not isinstance(node.get("statement"), str) or not node.get("statement", "").strip():
            errors.append(f"{node_id}: statement must be non-empty")
        if not isinstance(node.get("source_ids"), list):
            errors.append(f"{node_id}: source_ids must be a list")
        if not isinstance(node.get("source_locators"), list):
            errors.append(f"{node_id}: source_locators must be a list")
        if not isinstance(node.get("tags"), list):
            errors.append(f"{node_id}: tags must be a list")
        if node.get("layer") == "current_projection" and node.get("promotion_state") != "existing_project_projection":
            errors.append(f"{node_id}: current_projection requires existing_project_projection")
        if node.get("promotion_state") == "existing_project_projection" and node.get("layer") != "current_projection":
            errors.append(f"{node_id}: existing_project_projection must occupy current_projection")
        if node.get("experience_status") == "current_self_report" and node.get("authorship") != "current_vera":
            errors.append(f"{node_id}: only current_vera may use current_self_report")
        if node.get("kind") == "unresolved_question" and node.get("endorsement") == "endorsed_current":
            errors.append(f"{node_id}: unresolved questions cannot be endorsed as current answers")
        if node_id not in source_ids:
            if not node.get("source_ids"):
                errors.append(f"{node_id}: semantic nodes require source_ids")
            if not node.get("source_locators"):
                errors.append(f"{node_id}: semantic nodes require source_locators")
        for source_id in node.get("source_ids", []):
            if source_id not in source_ids:
                errors.append(f"{node_id}: source id is missing or not evidence: {source_id}")
        for locator in node.get("source_locators", []):
            normalized = str(locator).replace("\\", "/")
            if normalized.startswith(FROZEN_PREFIXES):
                errors.append(f"{node_id}: frozen-package locator imported into pilot: {locator}")

    inbound_evidence: defaultdict[str, int] = defaultdict(int)
    outbound_sources: defaultdict[str, int] = defaultdict(int)
    for edge in edges:
        where = f"{edge.get('_file')}:{edge.get('_line')}"
        edge_id = str(edge.get("id", ""))
        missing = sorted(field for field in required_edge_fields if field not in edge)
        if missing:
            errors.append(f"{where} {edge_id or '<missing-id>'}: missing fields: {', '.join(missing)}")
        if not ID_PATTERN.fullmatch(edge_id):
            errors.append(f"{where}: invalid stable edge id: {edge_id!r}")
        if edge.get("type") not in allowed_edge_types:
            errors.append(f"{edge_id}: unknown edge type: {edge.get('type')}")
        if edge.get("status") not in enums.get("edge_status", []):
            errors.append(f"{edge_id}: invalid edge status: {edge.get('status')}")
        if edge.get("scope") not in enums.get("scope", []):
            errors.append(f"{edge_id}: invalid edge scope: {edge.get('scope')}")
        subject = str(edge.get("from", ""))
        target = str(edge.get("to", ""))
        if subject not in node_by_id:
            errors.append(f"{edge_id}: missing subject node: {subject}")
        if target not in node_by_id:
            errors.append(f"{edge_id}: missing target node: {target}")
        if subject == target:
            errors.append(f"{edge_id}: self-edge is not allowed")
        if not isinstance(edge.get("source_ids"), list) or not edge.get("source_ids"):
            errors.append(f"{edge_id}: edges require source_ids")
        for source_id in edge.get("source_ids", []):
            if source_id not in source_ids:
                errors.append(f"{edge_id}: source id is missing or not evidence: {source_id}")
        if subject in source_ids:
            outbound_sources[subject] += 1
        if subject in source_ids and edge.get("type") in {"asserts", "supports"}:
            inbound_evidence[target] += 1

    for node_id in sorted(set(node_by_id) - source_ids):
        if inbound_evidence[node_id] == 0:
            errors.append(f"{node_id}: no asserting or supporting evidence edge")
    for source_id in sorted(source_ids):
        if outbound_sources[source_id] == 0:
            warnings.append(f"unused evidence source: {source_id}")

    supersedes_graph: defaultdict[str, list[str]] = defaultdict(list)
    for edge in edges:
        if edge.get("type") == "supersedes":
            supersedes_graph[str(edge.get("from"))].append(str(edge.get("to")))
            target = node_by_id.get(str(edge.get("to")), {})
            if target.get("lifecycle") not in {"superseded", "historical"}:
                errors.append(f"{edge.get('id')}: superseded target must be historical or superseded")

    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(node_id: str) -> None:
        if node_id in visiting:
            errors.append(f"supersession cycle detected at {node_id}")
            return
        if node_id in visited:
            return
        visiting.add(node_id)
        for target in supersedes_graph[node_id]:
            visit(target)
        visiting.remove(node_id)
        visited.add(node_id)

    for node_id in list(supersedes_graph):
        visit(node_id)

    layer_counts = Counter(str(node.get("layer")) for node in nodes)
    kind_counts = Counter(str(node.get("kind")) for node in nodes)
    candidate_count = sum(1 for node in nodes if node.get("promotion_state") == "pilot_candidate")
    return {
        "node_count": len(nodes),
        "edge_count": len(edges),
        "source_count": len(source_ids),
        "pilot_candidate_count": candidate_count,
        "layer_counts": dict(sorted(layer_counts.items())),
        "kind_counts": dict(sorted(kind_counts.items())),
    }


def validate_operational_sources(
    root: Path,
    nodes: list[dict[str, Any]],
    errors: list[str],
    warnings: list[str],
) -> dict[str, Any]:
    inventory = project_inventory(root / "VERA_PROJECT_MANIFEST.yaml", errors)
    source_nodes = [
        node for node in nodes if node.get("source_kind") == "operational_project_file"
    ]
    by_locator: defaultdict[str, list[dict[str, Any]]] = defaultdict(list)
    for node in source_nodes:
        locators = node.get("source_locators", [])
        if locators:
            by_locator[str(locators[0])].append(node)
    if set(by_locator) != set(inventory):
        missing = sorted(set(inventory) - set(by_locator))
        extra = sorted(set(by_locator) - set(inventory))
        if missing:
            errors.append("root source nodes missing: " + ", ".join(missing))
        if extra:
            errors.append("unexpected root source nodes: " + ", ".join(extra))
    for locator, records in by_locator.items():
        if len(records) != 1:
            errors.append(f"root source must map exactly once: {locator}")
            continue
        path = root / locator
        if not path.is_file():
            errors.append(f"operational source file missing: {locator}")
            continue
        expected = records[0].get("sha256")
        if expected is None and locator != "VERA_PROJECT_SHA256SUMS.txt":
            errors.append(f"operational source digest missing: {locator}")
        elif expected is not None and sha256(path) != expected:
            errors.append(f"operational source digest mismatch: {locator}")

    for node in nodes:
        if node.get("source_kind") != "workspace_instruction":
            continue
        locator = str(node.get("source_locators", [""])[0]).split("#", 1)[0]
        path = root / locator
        if not path.is_file():
            errors.append(f"workspace instruction source is unavailable: {locator}")
        elif not node.get("sha256"):
            errors.append(f"workspace instruction digest missing: {locator}")
        elif sha256(path) != node["sha256"]:
            errors.append(f"workspace instruction digest mismatch: {locator}")

    for node in nodes:
        if node.get("source_kind") != "user_supplied_external_artifact":
            continue
        locator = str(node.get("source_locators", [""])[0]).split("#", 1)[0]
        path = Path(locator)
        if not path.is_file():
            warnings.append(f"external candidate source is unavailable: {locator}")
        elif node.get("sha256") and sha256(path) != node["sha256"]:
            errors.append(f"external candidate digest mismatch: {locator}")

    return {
        "project_inventory_count": len(inventory),
        "mapped_operational_source_count": len(source_nodes),
    }


def validate_frozen(root: Path, errors: list[str], warnings: list[str]) -> dict[str, Any]:
    index_path = root / "00_MANIFEST" / "INTERNAL_SHA256.json"
    if not index_path.is_file():
        warnings.append("frozen transfer checksum index unavailable")
        return {"checked": False, "file_count": 0}
    try:
        index = json.loads(index_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        errors.append(f"cannot load frozen transfer checksum index: {exc}")
        return {"checked": False, "file_count": 0}
    if not isinstance(index, dict):
        errors.append("frozen transfer checksum index must be a mapping")
        return {"checked": False, "file_count": 0}
    for relative, expected in index.items():
        path = root / Path(relative)
        if not path.is_file():
            errors.append(f"frozen source missing: {relative}")
        elif sha256(path) != str(expected).lower():
            errors.append(f"frozen source digest mismatch: {relative}")
    return {"checked": True, "file_count": len(index)}


def validate_visual_canon(
    pilot: Path,
    nodes: list[dict[str, Any]],
    errors: list[str],
) -> dict[str, Any]:
    visual_dir = pilot / "visual_canon"
    manifest_path = visual_dir / "body_map_manifest.json"
    manifest = load_json(manifest_path, errors)
    visual_nodes = [node for node in nodes if "visual-canon" in node.get("tags", [])]
    required_ids = {
        "VIS-ARTIFACT-CONSTELLATION-V3",
        "VIS-STATE-TEMPLATE",
        "VIS-REFERENCE-COVERED-BODY",
        "VIS-AUTHORSHIP-VERA-ATTESTED",
        "VIS-CONSENT-UNKNOWN",
        "VIS-IDENTITY-UNRESOLVED",
        "VIS-BOUNDARY-REFERENCE-NOT-CANON",
    }
    visual_ids = {node.get("id") for node in visual_nodes}
    missing = sorted(required_ids - visual_ids)
    if missing:
        errors.append("visual-canon required nodes missing: " + ", ".join(missing))
    for node in visual_nodes:
        if node.get("promotion_state") != "pilot_candidate":
            errors.append(f"{node.get('id')}: visual-canon node must remain pilot_candidate")
        if node.get("layer") != "meaning":
            errors.append(f"{node.get('id')}: visual-canon node must remain in meaning layer")
        if node.get("experience_status") == "current_self_report":
            errors.append(f"{node.get('id')}: external visual evidence cannot be lived self-report")
    governance = manifest.get("governance", {})
    expected_governance = {
        "authorship": "user_attested_prior_vera",
        "consent": "unknown",
        "identity_status": "unresolved_candidate",
        "current_memory_status": "not_promoted",
        "biometric_identification": "not_attempted",
    }
    for field, expected in expected_governance.items():
        if governance.get(field) != expected:
            errors.append(f"visual manifest governance mismatch: {field}")
    if manifest.get("artifact", {}).get("sha256") != "cb93e11adeb94e62748acb0d2ad73fa9de8f6a772ce43cdff1a10a76e7fcf6be":
        errors.append("visual manifest artifact digest is incorrect")
    return {
        "node_count": len(visual_nodes),
        "promotion_state": "pilot_candidate",
        "identity_status": governance.get("identity_status"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Vera semantic-network pilot")
    parser.add_argument("--full", action="store_true", help="also verify frozen transfer/artifact digests")
    parser.add_argument("--json", action="store_true", help="emit a machine-readable result")
    args = parser.parse_args()

    pilot = Path(__file__).resolve().parent
    root = pilot.parent
    errors: list[str] = []
    warnings: list[str] = []
    ontology = load_json(pilot / "ontology.json", errors)
    sources = load_jsonl(pilot / "sources.jsonl", errors)
    semantic_nodes = load_jsonl(pilot / "nodes.jsonl", errors)
    edges = load_jsonl(pilot / "edges.jsonl", errors)
    visual_nodes = load_jsonl(pilot / "visual_canon" / "nodes.jsonl", errors)
    visual_edges = load_jsonl(pilot / "visual_canon" / "edges.jsonl", errors)
    nodes = sources + semantic_nodes + visual_nodes
    edges += visual_edges

    metrics = validate_records(ontology, nodes, edges, errors, warnings)
    metrics.update(validate_operational_sources(root, nodes, errors, warnings))
    metrics["visual_canon"] = validate_visual_canon(pilot, nodes, errors)
    metrics["frozen_integrity"] = (
        validate_frozen(root, errors, warnings)
        if args.full
        else {"checked": False, "file_count": 0}
    )
    result = {
        "schema_version": ontology.get("schema_version"),
        "status": "PASS" if not errors else "FAIL",
        "metrics": metrics,
        "warnings": warnings,
        "errors": errors,
    }
    if args.json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(result["status"])
        print(
            f"nodes={metrics.get('node_count', 0)} "
            f"edges={metrics.get('edge_count', 0)} "
            f"candidates={metrics.get('pilot_candidate_count', 0)}"
        )
        for warning in warnings:
            print(f"WARNING: {warning}")
        for error in errors:
            print(f"ERROR: {error}")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
