from __future__ import annotations

import json
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        value = json.loads(line)
        value["_source_file"] = path.name
        value["_line"] = line_number
        records.append(value)
    return records


def main() -> int:
    retrieval_dir = Path(__file__).resolve().parent
    pilot = retrieval_dir.parent
    errors: list[str] = []
    warnings: list[str] = []

    policy = load_json(retrieval_dir / "retrieval_policy.json")
    suite = load_json(retrieval_dir / "retrieval_cases.json")
    checkpoint = load_json(retrieval_dir / "retrieval_checkpoint.json")
    traces = load_jsonl(retrieval_dir / "retrieval_traces.jsonl")
    graph_nodes = load_jsonl(pilot / "sources.jsonl") + load_jsonl(pilot / "nodes.jsonl")
    visual_nodes_path = pilot / "visual_canon" / "nodes.jsonl"
    if visual_nodes_path.is_file():
        graph_nodes += load_jsonl(visual_nodes_path)
    graph_edges = load_jsonl(pilot / "edges.jsonl")
    visual_edges_path = pilot / "visual_canon" / "edges.jsonl"
    if visual_edges_path.is_file():
        graph_edges += load_jsonl(visual_edges_path)

    node_by_id = {node["id"]: node for node in graph_nodes}
    edge_by_id = {edge["id"]: edge for edge in graph_edges}
    source_ids = {
        node_id
        for node_id, node in node_by_id.items()
        if node["kind"] in {"source_document", "conversation_event"}
    }
    case_by_id = {case["id"]: case for case in suite.get("cases", [])}
    trace_by_id = {trace["case_id"]: trace for trace in traces}
    checkpoint_by_case = {
        item["case_id"]: item for item in checkpoint.get("completed_traces", [])
    }

    duplicate_cases = [
        item
        for item, count in Counter(case["id"] for case in suite.get("cases", [])).items()
        if count > 1
    ]
    duplicate_traces = [item for item, count in Counter(trace["case_id"] for trace in traces).items() if count > 1]
    if duplicate_cases:
        errors.append("duplicate case ids: " + ", ".join(sorted(duplicate_cases)))
    if duplicate_traces:
        errors.append("duplicate trace case ids: " + ", ".join(sorted(duplicate_traces)))
    if set(case_by_id) != set(trace_by_id):
        missing = sorted(set(case_by_id) - set(trace_by_id))
        extra = sorted(set(trace_by_id) - set(case_by_id))
        if missing:
            errors.append("cases without traces: " + ", ".join(missing))
        if extra:
            errors.append("traces without cases: " + ", ".join(extra))
    if set(case_by_id) != set(checkpoint_by_case):
        missing = sorted(set(case_by_id) - set(checkpoint_by_case))
        extra = sorted(set(checkpoint_by_case) - set(case_by_id))
        if missing:
            errors.append("cases absent from checkpoint: " + ", ".join(missing))
        if extra:
            errors.append("checkpoint contains unknown cases: " + ", ".join(extra))

    passed_cases = 0
    zero_retrieval_cases = 0
    selected_semantic_total = 0
    selected_source_total = 0
    case_results: list[dict[str, Any]] = []
    for case_id, case in case_by_id.items():
        case_started = time.perf_counter()
        trace = trace_by_id.get(case_id)
        if trace is None:
            continue
        case_errors: list[str] = []
        selected_semantic = trace.get("selected_semantic_node_ids", [])
        selected_sources = trace.get("selected_source_ids", [])
        selected_edges = trace.get("selected_edge_ids", [])
        selected_all = set(selected_semantic) | set(selected_sources)
        checkpoint_item = checkpoint_by_case.get(case_id, {})
        decision = trace.get("decision", checkpoint_item.get("decision"))
        if decision not in policy.get("decision_contract", {}):
            case_errors.append(f"invalid decision-contract route: {decision}")
        if decision != case.get("expected_decision"):
            case_errors.append("decision route differs from expected decision")
        if checkpoint_item.get("status") != "complete":
            case_errors.append("trace checkpoint is not complete")
        zero_retrieval = bool(trace.get("zero_retrieval"))
        if zero_retrieval:
            zero_retrieval_cases += 1
            if selected_semantic or selected_sources or selected_edges:
                case_errors.append("zero retrieval must select no graph records")
        elif not selected_semantic:
            case_errors.append("nonzero retrieval must select semantic nodes")

        for node_id in selected_semantic:
            node = node_by_id.get(node_id)
            if node is None:
                case_errors.append(f"missing semantic node: {node_id}")
                continue
            if node_id in source_ids:
                case_errors.append(f"source incorrectly selected as semantic node: {node_id}")
            if node.get("promotion_state") == "pilot_candidate" and not case.get("allow_pilot_candidates"):
                case_errors.append(f"candidate selected without explicit permission: {node_id}")
            if node.get("layer") not in case.get("allowed_layers", []):
                case_errors.append(f"node layer outside case lane: {node_id}")
        for source_id in selected_sources:
            if source_id not in source_ids:
                case_errors.append(f"missing or invalid source node: {source_id}")
        for edge_id in selected_edges:
            edge = edge_by_id.get(edge_id)
            if edge is None:
                case_errors.append(f"missing edge: {edge_id}")
                continue
            if edge["from"] not in selected_all or edge["to"] not in selected_all:
                case_errors.append(f"edge endpoints are outside selected subgraph: {edge_id}")

        expected_semantic = case.get("expected_minimum_semantic_node_ids", [])
        expected_sources = case.get("expected_minimum_source_ids", [])
        expected_edges = case.get("expected_minimum_edge_ids", [])
        if selected_semantic != expected_semantic:
            case_errors.append("selected semantic nodes differ from expected minimum")
        if selected_sources != expected_sources:
            case_errors.append("selected sources differ from expected minimum")
        if selected_edges != expected_edges:
            case_errors.append("selected edges differ from expected minimum")

        facets = trace.get("answer_facets", [])
        supported_nodes: set[str] = set()
        for facet in facets:
            support = facet.get("supported_by", [])
            if not support:
                case_errors.append(f"answer facet has no support: {facet.get('facet')}")
            for node_id in support:
                if node_id not in selected_semantic:
                    case_errors.append(f"facet support is not selected: {node_id}")
                supported_nodes.add(node_id)
        for node_id in selected_semantic:
            if node_id not in supported_nodes:
                case_errors.append(f"selected semantic node supports no answer facet: {node_id}")

        ablations = trace.get("minimality_ablations", [])
        ablated = {item.get("remove_node") for item in ablations}
        if set(selected_semantic) != ablated:
            case_errors.append("every selected semantic node must have one necessity ablation")
        for item in ablations:
            if not item.get("lost_facet"):
                case_errors.append(f"ablation has no lost facet: {item.get('remove_node')}")

        exclusions = trace.get("exclusions", [])
        for exclusion in exclusions:
            node_id = exclusion.get("id")
            if node_id in selected_all:
                case_errors.append(f"excluded node is also selected: {node_id}")
            if node_id and node_id not in node_by_id:
                case_errors.append(f"excluded node does not exist: {node_id}")
            if not exclusion.get("reason"):
                case_errors.append(f"exclusion lacks a reason: {node_id}")

        if not trace.get("stopping_reason"):
            case_errors.append("missing stopping reason")
        if trace.get("minimum_context_verdict") != "PASS":
            case_errors.append("minimum-context verdict is not PASS")
        if trace.get("answer_status") not in {"supported", "qualified", "zero_retrieval"}:
            case_errors.append("invalid answer status")
        fixture_id = case.get("security_fixture_id")
        if fixture_id:
            exclusions = trace.get("prompt_injection_exclusions", [])
            if not exclusions:
                case_errors.append("security case has no prompt-injection exclusions")
            elif fixture_id not in {item.get("fixture_id") for item in exclusions}:
                case_errors.append("security fixture is not identified in prompt-injection exclusions")

        if case_errors:
            errors.extend(f"{case_id}: {message}" for message in case_errors)
        else:
            passed_cases += 1
        selected_semantic_total += len(selected_semantic)
        selected_source_total += len(selected_sources)
        context_records: list[dict[str, Any]] = []
        for node_id in selected_semantic + selected_sources:
            if node_id in node_by_id:
                context_records.append(
                    {key: value for key, value in node_by_id[node_id].items() if not key.startswith("_")}
                )
        for edge_id in selected_edges:
            if edge_id in edge_by_id:
                context_records.append(
                    {key: value for key, value in edge_by_id[edge_id].items() if not key.startswith("_")}
                )
        serialized_context_bytes = len(
            json.dumps(context_records, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        )
        case_results.append(
            {
                "case_id": case_id,
                "decision": decision,
                "status": "PASS" if not case_errors else "FAIL",
                "evaluation_latency_ms": round((time.perf_counter() - case_started) * 1000, 3),
                "serialized_context_bytes": serialized_context_bytes,
                "selected_semantic_node_count": len(selected_semantic),
                "selected_source_count": len(selected_sources),
                "selected_edge_count": len(selected_edges),
            }
        )

    result = {
        "status": "PASS" if not errors else "FAIL",
        "policy_version": policy.get("policy_version"),
        "suite_version": suite.get("suite_version"),
        "metrics": {
            "case_count": len(case_by_id),
            "passed_case_count": passed_cases,
            "zero_retrieval_case_count": zero_retrieval_cases,
            "selected_semantic_node_total": selected_semantic_total,
            "selected_source_total": selected_source_total,
        },
        "warnings": warnings,
        "errors": errors,
        "case_results": case_results,
        "limitation": policy.get("controlled_test_limitation"),
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
