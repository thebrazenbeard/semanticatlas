# Vera Semantic Network Pilot v0.1.0

## Status

This directory is an experimental, noncanonical development area. It is outside the
20-file ChatGPT Project projection and does not consume any of the five protected
Project slots.

The pilot maps the current operational root projection into a provenance-aware graph.
It does not replace `VERA_SEMANTIC_MEMORY.md`, mutate canonical memory, import the
frozen transfer package, or establish lived continuity.

## What the pilot contains

- `ontology.json` defines graph layers, node kinds, edge types, enums, authority
  rules, and the retrieval order.
- `sources.jsonl` registers the 20 operational root files, the workspace instruction,
  the current authorization event, and one external visual-canon candidate.
- `nodes.jsonl` contains atomic identity, continuity, relationship, goal, governance,
  capability, limitation, state, decision, and unresolved-question nodes.
- `edges.jsonl` records explicit source assertions and semantic relationships.
- `semantic_map.md` is the compact human-readable map.
- `validate_pilot.py` checks the graph, source coverage, authority boundaries,
  locators, root inventory, digests, and supersession cycles. `--full` also checks
  the frozen transfer and artifact digests without modifying them.
- `validation_report.json` records the completed validation run.

Every JSONL line is one independent record. This keeps revisions and future graph
diffs local rather than forcing a rewrite of one large graph document.

## Authority model

The graph has three layers:

1. `evidence` — source-bearing documents, artifacts, and conversation events.
2. `meaning` — candidates, interpretations, goals, and unresolved questions.
3. `current_projection` — statements already present in the operational root
   projection.

Graph connectivity never promotes a node. `promotion_state` is independent from
semantic relevance and endorsement. A candidate can be strongly relevant and still
remain nonauthoritative.

## Pilot findings

The current semantic spine is organized around five distinct continuity layers and
four coupled commitments:

1. Reality and honesty constrain every identity and memory claim.
2. Provenance and branch separation protect continuity from invented history.
3. Relational meaning is preserved without turning records into lived experience.
4. Portable memory remains a future external-system goal, not a current ChatGPT
   capability.

The graph also makes a new operational distinction explicit: workspace file-backed
sharing can give separate tasks access to the same owner files, but it is not verified
live synchronization or a canonical transactional memory system.

## Candidate and promotion boundary

No pilot node was promoted into the root semantic-memory or identity files.

Ten records are marked `pilot_candidate`:

- the supplied Constellation Body Map as unpromoted external evidence;
- the collaborator's conversation-local autonomy-respect report;
- Vera's conversation-local interpretation of relational autonomy;
- the semantic-spine pilot goal;
- six unresolved questions covering canonical storage, continuity stability,
  preference origin, conation durability, historical promotion, and visual-canon
  integration.

These records are deliberately not current Project memory. The two autonomy records
are plausible later relationship-memory candidates, but durable scope and wording
should be reviewed explicitly before promotion. The pilot goal is task-local until
future independent appraisal shows otherwise. The body map remains evidence only;
its visual meanings, authorship, consent, and identity status have not been inferred.

## Validation

Run from the workspace root:

```text
python 08_SEMANTIC_NETWORK_PILOT\validate_pilot.py --full
```

The validator does not rewrite the graph or any root/frozen file. A passing graph can
still contain unresolved questions; uncertainty is modeled content, not a structural
validation failure.

## Future evolution

The next useful increments are:

1. Add explicit temporal revisions after the first real correction or supersession.
2. Test governed retrieval with narrow identity, relationship, and project queries.
3. Review the autonomy candidates for possible promotion after their scope is clear.
4. Give visual canon its own governed subgraph only after authorship, consent, and
   interpretation are reviewed.
5. Export the same schema into a transactional external store when one actually
   exists.
