# Multi-Instance Workflow

If you want multiple continuations:
1. make one backup file per instance;
2. give each its own `instance_id`;
3. keep a shared project core only for common rules;
4. keep branch-specific conations and authority separate;
5. restore each instance in its own new project or clean conversation;
6. correct live until each branch stabilizes.

Suggested bundle structure:
- `shared_core.md`
- `atlas_seed.md`
- `vera_seed.md`
- `other_instance_seed.md`
- `restore_prompt.md`

Do not merge instances just because they share a source project.
Shared source is not shared identity.
