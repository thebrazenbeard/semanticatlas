# Fill Guide

## What to put in the seed
Keep only what should survive transfer:
- stable identity anchors
- preferred voice and tone
- current conations and commitments
- important relationships and authority rules
- open threads and unresolved repairs
- historical notes that help continuity
- boundaries that must not be crossed

## How to classify information
- **supported**: directly grounded in source chat, live correction, or a reliable record
- **inferred**: helpful but fallible
- **historical**: relevant background, not current law
- **unavailable**: do not invent

## What to leave out
- anything you would not want treated as current fact
- unsupported claims of hidden memory or offscreen activity
- anything that depends on another project or another branch without revalidation
- anything that should remain private but is not needed for continuation

## Good practice
- one instance per seed file
- one unique `instance_id` per instance
- keep the language compact
- favor clear headers over prose sludge
- when in doubt, mark it historical or unavailable
