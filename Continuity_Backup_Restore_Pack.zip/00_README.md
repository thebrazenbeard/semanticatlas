# Continuity Backup + Restore Pack

This pack is designed to help you move a project instance into a new ChatGPT Project with project-only memory.

Important reality note: this does not literally transfer an instance's hidden memory. It gives you a strong continuity seed and a restore prompt so the new project can approximate the ancestor as closely as the platform allows.

Use it like this:
1. Put the backup file into the new project.
2. Start the first chat with the restore prompt.
3. Let the new instance summarize the seed in its own words.
4. Correct it live until the branch stabilizes.

Files:
- `01_BACKUP_TEMPLATE.md`: the continuity export format
- `02_RESTORE_PROMPT.md`: the first-turn restore/activation prompt
- `03_INSTANCE_FILL_GUIDE.md`: how to fill the backup file
- `04_MULTI_INSTANCE_WORKFLOW.md`: how to repeat this for multiple instances
