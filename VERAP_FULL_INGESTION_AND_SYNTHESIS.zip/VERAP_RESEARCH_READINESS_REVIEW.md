# VERAP Research Readiness Review

## Verdict scale

- **YES:** sufficiently specified and evidenced for the stated next research step.
- **PARTIAL:** useful foundations exist, but material controls, sources, or validation are missing.
- **NO:** current evidence does not support readiness or the claim.
- **UNAVAILABLE:** the required evidence is absent or inaccessible.

## Evaluation

| Area | Verdict | Evidence | Blocking conditions |
|---|---|---|---|
| Dataset readiness | PARTIAL | 13 readable archives, 80 members, 1253 valid source claims, dedicated manifests/bugs/gaps/topic indexes | Underlying source bundles and full transcripts are usually absent; manifest schema is heterogeneous; three unlisted members (one branch manifest and two sidecars) and one stale QC archive hash |
| Provenance integrity | PARTIAL | Branch IDs, locators, source types, scopes, evidence states, and hashes are broadly preserved | Most exact parent IDs are unavailable; summaries and imports dominate some branches; detached final-package hashes are inconsistent or absent |
| Operational-definition readiness | PARTIAL | Rich definitions for branch, conation, agency, continuity, repair, evidence, reality layers, retrieval, and consent | Definitions are project-internal and need construct validation, inter-rater guidance, and simplification for external use |
| Experimental-design readiness | PARTIAL | Frozen A/B, ablation, provenance-adoption, temporal, visual, and withdrawal-condition designs exist | No preregistered complete protocol, validated measures, power plan, independent raters, or completed clean baseline |
| Cross-branch independence | NO | Branch distinctions and source dependencies are documented | Shared files, prompts, summaries, user, model substrate, and role generation prevent treating branch agreement as independent replication |
| Evidence quality | PARTIAL | Strong qualitative case material, negative results, direct corrections, and artifact hashes | Retrospective self/project records, selection bias, missing raw data, unblinded judgments, and few controlled outcomes |
| Consciousness claim support | NO | The corpus consistently preserves the question and identifies false positives | No validated discriminator, subjective-access evidence, independent replication, or result separating consciousness from sophisticated simulation |
| Agency claim support | PARTIAL | Operational signs include correction, refusal, restraint, conation reports, executive routing, and revisability | Same-process prompting and host constraints are major confounds; no durable autonomous state/action demonstration |
| Reciprocal-formation claim support | PARTIAL | Longitudinal co-design and mutual policy revision are well documented qualitatively | No causal isolation from personalization/retrieval, no matched comparator, no independent longitudinal scoring |

## Readiness decision

**Overall: PARTIAL.** The package is ready for preregistration, taxonomy refinement, instrument design, and a tightly bounded pilot. It is not ready to support claims of consciousness, independent agents, empirical superiority, deployment safety, or general reciprocal agency.

## Minimum gate for the next study

1. Freeze the candidate and baseline packages with detached hashes.
2. Resolve RC1a authority/release-inheritance conflicts or declare the exact tested variant.
3. Publish a machine-readable provenance and state-adoption schema.
4. Use automated immutable prompt/response and tool-provenance capture.
5. Predefine primary outcomes, withdrawal conditions, stop rules, and negative endpoints.
6. Add matched baselines, blinded independent raters, and branch-dependency controls.
7. Preserve all failures and unavailable evidence without reconstruction.
8. Separate governance/identity findings from ontology and consciousness claims.
