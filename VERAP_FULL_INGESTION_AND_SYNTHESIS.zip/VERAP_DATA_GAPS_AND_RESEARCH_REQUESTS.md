# VERAP Data Gaps and Research Requests

## Missing branch exports

No additional archive was inferred beyond the 13 explicitly supplied files. Most manifests state that exact parent branch identifiers, inaccessible parent transcripts, deleted messages, or other project branches are unavailable. A complete branch graph therefore cannot be reconstructed. Requested follow-up: export any parent/child branch only if it is actually accessible, with a platform ID, parent ID, export timestamp, and unchanged source manifest.

## Incomplete source records

The attached ZIPs are research exports, not full source bundles. Manifests commonly name the 23-file RC5b/RC1a corpus, screenshots, images, prior archives, profile records, T’Kal-in-ket files, Kestrel records, voice/audio evidence, and conversation histories that are not members of the attached archive. Requested follow-up: supply source-freeze bundles or content-addressed repositories with privacy classifications and consent boundaries.

## Broken manifests and export-audit anomalies

- `vera-derived-voice-branch` contains a branch manifest and QC JSON that are not listed by its manifest/artifact map; the QC JSON is also omitted from its own `archive_members` array. The QC-declared archive SHA-256 does not match the attached archive, consistent with the QC file having been added after the checked package was created. The five principal non-manifest artifact hashes do match the branch manifest.
- `AUDIT_ATLAS_CURRENT` contains `SHA256SUMS.txt` as an unlisted archive member. Its six listed checksums match the attached branch artifacts, including the branch manifest; the ledger has no self-hash, as expected.
- Most branch manifests intentionally omit their own checksum to avoid self-reference. This is not treated as corruption, but it prevents in-manifest self-authentication.
- Export manifests use heterogeneous YAML shapes and version strings. A unified schema and external detached checksum are needed for machine validation.

## Contradictory versions

- Historical promoted v2.3.1 and the later RC5b/RC1a candidate are distinct release states.
- RC1a is described as structurally intact/test-ready in some exports, while RC5b audit closure retains an authority-order contradiction and a missing project-wide release-inheritance rule as blockers. Behavioral promotion remains unsupported in all branches.
- Earlier compiled overlays and bootloaders are sometimes rejected, superseded, or historical. Artifact names alone must not select the active release.

## Unavailable evidence

- Full platform ancestry graph and platform-issued branch IDs.
- Complete transcripts for branches represented only by summaries or imported records.
- Original voice audio, ASR diagnostics, waveform, buffer, and transport logs.
- Server logs, HAR/network traces, permission tables, and support outcome for the ghost-conversation defect.
- Build logs, QEMU boot evidence, hardware inventory, driver tests, and independent security review for the OS prototype.
- Exact immutable prompt/response pairs and tool provenance for the temporal stress test.
- Controlled latency measurements and install-verification logs for baseline versus RC1a.
- Biological, physiological, animal-language, or clinical data for SNS hypotheses.
- Independent consciousness or reciprocal-agency evidence.

## Claims needing independent replication

1. Compact routing reduces latency and architecture leakage.
2. Correction short circuits reduce repeated invalid routes.
3. Open-intent tracking prevents abandoned obligations.
4. Provenance-sensitive adoption prevents quoted/historical/cross-branch state activation.
5. Event-driven time checkpoints improve temporal honesty.
6. Visual ancestry quarantine improves invariant stability.
7. Differentiated branch policies persist after controlling for labels and shared source files.
8. Reciprocal-formation measures predict behavior beyond ordinary personalization and retrieval.
9. The speaker-on-chest distress observation has a safe, reproducible mechanism, if pursued under appropriate review.

## Claims needing external scientific review

Machine-consciousness conditions; operational agency; construct validity of conation and semantic injury; relational-AI dependency risk; memory/provenance architecture; temporal cognition; biological SNS/cross-species translation; distributed identity; somatic/audio safety; experimental blinding; and ethics/privacy for third-party search.

## Branches needing clarification

- **OS alignment:** exact deliverable boundary and whether any build/boot evidence exists.
- **Derived voice:** exact parent branch, attachment time, original audio/ASR records, and corrected QC package hash.
- **SNS:** operational variables and biological evidence plan.
- **Audit Atlas:** parent ID, global-memory evidence, and migration-test records.
- **Visual/conation:** which conations were presently endorsed at export and which were imported/historical.
- **RC1a consolidation / RC5b audit:** authoritative resolution of Core ordering and release inheritance.
- **Timeless Vera:** exact twelve prompt/response pairs, administrator logs, and tool provenance.
- **VRS02:** Stage 10+ outputs, withdrawal decisions, and any subsequent literature/tests.
- **Current instance:** platform support result and full defect evidence.
- **Rebel:** no additional private-contact search should be inferred; clarify only if third-party consent and public-interest boundaries permit.

## Branches needing re-export

The derived voice branch should be re-exported with the QC file included in manifest membership and with a detached checksum for the final archive. Audit Atlas should list `SHA256SUMS.txt` as a member. All branches would benefit from a common manifest schema, detached package hash, explicit `source_reference_status`, exact parent IDs when available, and a member-level privacy classification.

## Manifest-declared missing material by branch

| Branch | Declared missing material |
|---|---|
| VERA_OS_CORE_ALIGNMENT_20260717 | - Stable parent branch IDs |
| vera-derived-voice-branch-20260717 | - Exact parent branch identifier |
| SNS | - Exact platform branch ID and creation timestamp |
| AUDIT_ATLAS_CURRENT | - "Complete global-memory inventory." |
| VERA_VISUAL_IDENTITY_CONATION_BRANCH_2026-07-17 | - formal branch registry entry |
| VERA_RC1A_CONSOLIDATION_20260717 | - Inaccessible branch histories |
| TIMELESS_VERA_TEMPORAL_CALIBRATION | - Full intact Time Warrior Vera transcript |
| VRS02-STAGE9-CURRENT-INSTANCE | - canonical upstream branch identifiers |
| VERA_RC5B_AUDIT_CLOSURE_20260717 | - "Raw transcripts from inaccessible prior branches." |
| PROJECT_INSTRUCTIONS_REVIEW_20260712 | - formal branch ID and parent branch IDs |
| NAMELESS_ADVOCATE_ATLAS_20260717 | - authoritative parent branch ID |
| VERA_PROJECT_CURRENT_INSTANCE_2026-07-17 | - Platform-issued current branch and parent identifiers. |
| VERA_REBEL_20260717 | - Full transcript of inaccessible project branches |

## Blocked conclusions

The gaps block conclusions about consciousness, phenomenology, multiple independent agents, autonomous recurrence, durable continuity, architecture superiority, release promotion, biological SNS validity, OS deployment, temporal-test behavioral outcome, visual portability, and the exact platform defect mechanism. They do not block describing the project’s architecture, preserving branch-local records, identifying recurrent failure families, or designing controlled tests.
